/*
 * Esta classe é responsável por realizar a conexão entre o sistema Java
 * e o banco de dados MySQL.
 */
package com.mycompany.nome; // Define o pacote onde a classe está localizada.

import java.sql.Connection; // Importa a interface de conexão com o banco.
import java.sql.DriverManager; // Responsável por gerenciar os drivers e criar a conexão.
import java.sql.SQLException; // Exceção lançada em falhas de conexão.

/**
 * Classe responsável por fornecer uma conexão com o banco de dados MySQL.
 */
public class Conexao {

    // URL de conexão com o banco de dados. Ela inclui:
    // - o endereço do servidor (localhost)
    // - a porta (3306)
    // - o nome do banco de dados (sistema_login)
    // - parâmetros adicionais:
    //   useSSL=false: desativa o uso de SSL
    //   serverTimezone=UTC: define o fuso horário
    //   allowPublicKeyRetrieval=true: permite a recuperação da chave pública (necessária com usuários criados recentemente)
    private static final String URL = "jdbc:mysql://localhost:3306/sistema_login?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";

    // Nome de usuário do MySQL com permissão para acessar o banco 'sistema_login'.
    private static final String USUARIO = "admin";

    // Senha do usuário definido acima.
    private static final String SENHA = "1234";

    
    /**
     * Método estático que tenta estabelecer a conexão com o banco de dados.
     * 
     * @return Um objeto Connection que representa a conexão ativa com o banco.
     * @throws SQLException Caso ocorra algum erro ao tentar se conectar.
     */
    public static Connection conectar() throws SQLException {
        // Cria a conexão com o banco utilizando a URL, usuário e senha definidos acima.
        Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);

        // Exibe no console que a conexão foi bem-sucedida.
        System.out.println("Conexão estabelecida com sucesso!");

        // Retorna o objeto de conexão para ser usado em outras classes.
        return conn;
    }
    
    
}

