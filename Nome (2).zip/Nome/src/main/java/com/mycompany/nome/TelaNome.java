/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.nome; // Define o pacote do projeto

import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import org.mindrot.jbcrypt.BCrypt;

/**
 * Classe principal da interface gráfica (JFrame) para cadastro de usuários.
 *
 * @author Gato
 */
public class TelaNome extends javax.swing.JFrame {

    private static final Logger LOGGER = Logger.getLogger(TelaNome.class.getName());

    // Construtor da classe TelaNome
    public TelaNome() {
        initComponents(); // Inicializa componentes da interface (botões, campos, etc)
        jBotaoAtualizarActionPerformed(null); // Carrega dados da tabela ao iniciar a tela

    }

    // Validação do nome de usuário: somente letras, números, underline, entre 4 e 20 caracteres
    private boolean validarUsuario(String usuario) {
        return usuario != null && usuario.matches("^[a-zA-Z0-9_]{4,20}$");
    }

// Validação de senha forte: pelo menos 8 caracteres, 1 letra minúscula, 1 maiúscula, 1 número, 1 caractere especial
    private boolean validarSenhaForte(String senha) {
        if (senha == null) {
            return false;
        }
        return senha.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!@#\\$%\\^&\\*\\-_\\+=])[A-Za-z\\d!@#\\$%\\^&\\*\\-_\\+=]{8,}$");
    }

    private int tentativasLogin = 0;
    private final int MAX_TENTATIVAS = 3;

// Método auto-gerado pelo NetBeans para inicializar componentes visuais
    @SuppressWarnings("unchecked")
    // Aqui o NetBeans cria e configura todos os componentes gráficos:
    // jPanel1, jLabels, jTextFields para usuário e senha,
    // botões para entrar, sair, cadastrar, alterar, deletar, resetar,
    // e a tabela para mostrar os dados dos usuários.
    // Também define layout, fonte, tamanhos e associa eventos (ActionListeners).
    // (Código extenso, gerado automaticamente)

    // Ações dos componentes (eventos)
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jUsuario = new javax.swing.JTextField();
        jSenha = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jBotaoEntrar = new javax.swing.JButton();
        jBotaoSair = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTabelaCadastro = new javax.swing.JTable();
        jBotaoCadastro = new javax.swing.JButton();
        jBotaoAtualizar = new javax.swing.JButton();
        jBotaoAlterar = new javax.swing.JButton();
        jBotaoDeletar = new javax.swing.JButton();
        jBotaoResetar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Cadastro");

        jUsuario.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jUsuarioActionPerformed(evt);
            }
        });

        jSenha.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSenhaActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel2.setText("Usuário:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel3.setText("Senha:");

        jBotaoEntrar.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jBotaoEntrar.setText("Entrar");
        jBotaoEntrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBotaoEntrarActionPerformed(evt);
            }
        });

        jBotaoSair.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jBotaoSair.setText("Sair");
        jBotaoSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBotaoSairActionPerformed(evt);
            }
        });

        jTabelaCadastro.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jTabelaCadastro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null}
            },
            new String [] {
                "Dados"
            }
        ));
        jScrollPane1.setViewportView(jTabelaCadastro);

        jBotaoCadastro.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jBotaoCadastro.setText("Cadastro");
        jBotaoCadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBotaoCadastroActionPerformed(evt);
            }
        });

        jBotaoAtualizar.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jBotaoAtualizar.setText("Atualizar");
        jBotaoAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBotaoAtualizarActionPerformed(evt);
            }
        });

        jBotaoAlterar.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jBotaoAlterar.setText("Alterar");
        jBotaoAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBotaoAlterarActionPerformed(evt);
            }
        });

        jBotaoDeletar.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jBotaoDeletar.setText("Deletar");
        jBotaoDeletar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBotaoDeletarActionPerformed(evt);
            }
        });

        jBotaoResetar.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jBotaoResetar.setText("Resetar");
        jBotaoResetar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBotaoResetarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
                        .addComponent(jSenha))
                    .addComponent(jLabel3)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jBotaoEntrar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jBotaoSair)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jBotaoResetar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jBotaoAtualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jBotaoCadastro)
                        .addComponent(jBotaoAlterar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jBotaoDeletar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jBotaoCadastro)
                        .addGap(18, 18, 18)
                        .addComponent(jBotaoAtualizar)
                        .addGap(18, 18, 18)
                        .addComponent(jBotaoAlterar)
                        .addGap(18, 18, 18)
                        .addComponent(jBotaoDeletar)
                        .addGap(18, 18, 18)
                        .addComponent(jBotaoResetar))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jBotaoEntrar)
                            .addComponent(jBotaoSair))))
                .addGap(0, 85, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jUsuarioActionPerformed

    }//GEN-LAST:event_jUsuarioActionPerformed

    private void jSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSenhaActionPerformed

    }//GEN-LAST:event_jSenhaActionPerformed

    private void jBotaoEntrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBotaoEntrarActionPerformed
        if (jUsuario.getText().trim().isEmpty() || jSenha.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha todos os campos!");
            return;
        }

        String usuario = jUsuario.getText().trim();
        String senha = jSenha.getText().trim();

        try (Connection conexao = Conexao.conectar()) {
            String sql = "SELECT senha FROM usuarios WHERE nome = ?";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, usuario);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String senhaHash = rs.getString("senha");
                if (BCrypt.checkpw(senha, senhaHash)) {
                    JOptionPane.showMessageDialog(this, "Login bem-sucedido!");
                    tentativasLogin = 0;

                    // Ativa botões administrativos se for admin
                    if (usuario.equals("admin")) {
                        jBotaoAlterar.setEnabled(true);
                        jBotaoDeletar.setEnabled(true);
                        jBotaoResetar.setEnabled(true);
                    } else {
                        jBotaoAlterar.setEnabled(false);
                        jBotaoDeletar.setEnabled(false);
                        jBotaoResetar.setEnabled(false);
                    }

                    return;
                }
            }

            // Se chegou aqui, falhou login
            tentativasLogin++;
            if (tentativasLogin >= MAX_TENTATIVAS) {
                JOptionPane.showMessageDialog(this, "Muitas tentativas. Acesso bloqueado temporariamente.");
                jBotaoEntrar.setEnabled(false);

                new java.util.Timer().schedule(new java.util.TimerTask() {
                    @Override
                    public void run() {
                        tentativasLogin = 0;
                        jBotaoEntrar.setEnabled(true);
                    }
                }, 10000); // 10 segundos de bloqueio

            } else {
                JOptionPane.showMessageDialog(this, "Usuário ou senha inválidos!");
            }

            rs.close();
            stmt.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao tentar realizar o login.");
            LOGGER.log(Level.SEVERE, "Erro ao realizar login", e);
        }
    }//GEN-LAST:event_jBotaoEntrarActionPerformed

    private void jBotaoSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBotaoSairActionPerformed
        System.exit(0); // Encerra o programa
    }//GEN-LAST:event_jBotaoSairActionPerformed

    private void jBotaoCadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBotaoCadastroActionPerformed
        String usuario = jUsuario.getText().trim();
        String senha = jSenha.getText().trim();

        if (!validarUsuario(usuario)) {
            JOptionPane.showMessageDialog(this, "Usuário inválido! Use 4-20 caracteres com letras, números ou '_'.");
            return;
        }

        if (!validarSenhaForte(senha)) {
            JOptionPane.showMessageDialog(this, "Senha fraca! Use pelo menos 8 caracteres, incluindo letras maiúsculas, minúsculas, números e símbolos.");
            return;
        }

        try (Connection conexao = Conexao.conectar()) {
            String senhaHash = BCrypt.hashpw(senha, BCrypt.gensalt());

            String sql = "INSERT INTO usuarios (nome, senha, senha_visivel) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setString(1, usuario);
                stmt.setString(2, senhaHash);
                stmt.setString(3, senha); // armazenar senha visível
                stmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Usuário cadastrado com sucesso!\nSenha: " + senha);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao cadastrar: " + e.getMessage());
        }
    }//GEN-LAST:event_jBotaoCadastroActionPerformed

    private void jBotaoAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBotaoAtualizarActionPerformed
        try (Connection conexao = Conexao.conectar()) {
            String sql = "SELECT id, nome, senha_visivel FROM usuarios";
            Statement stmt = conexao.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            DefaultTableModel modelo = new DefaultTableModel(
                    new Object[]{"ID", "Nome", "Senha"}, 0
            ) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                String senhaVisivel = rs.getString("senha_visivel"); // pega senha real
                modelo.addRow(new Object[]{id, nome, senhaVisivel});
            }

            jTabelaCadastro.setModel(modelo);

            rs.close();
            stmt.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao atualizar tabela: " + e.getMessage());
        }
    }//GEN-LAST:event_jBotaoAtualizarActionPerformed

    private void jBotaoAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBotaoAlterarActionPerformed
        int linha = jTabelaCadastro.getSelectedRow();

        if (linha >= 0) {
            Object valorId = jTabelaCadastro.getValueAt(linha, 0);

            if (valorId != null) {
                int id = Integer.parseInt(valorId.toString());
                String nomeNovo = jUsuario.getText().trim();
                String senhaNova = jSenha.getText().trim();

                // Perguntar senha atual para confirmar alteração
                String senhaConfirmacao = JOptionPane.showInputDialog(this, "Digite a senha atual para confirmar alteração:");

                if (senhaConfirmacao == null || senhaConfirmacao.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Alteração cancelada: senha não informada.");
                    return;
                }

                try (Connection conexao = Conexao.conectar()) {
                    // Verificar senha atual do usuário no banco
                    String sqlBusca = "SELECT senha FROM usuarios WHERE id = ?";
                    PreparedStatement stmtBusca = conexao.prepareStatement(sqlBusca);
                    stmtBusca.setInt(1, id);
                    ResultSet rs = stmtBusca.executeQuery();

                    if (rs.next()) {
                        String senhaHashAtual = rs.getString("senha");
                        if (!BCrypt.checkpw(senhaConfirmacao, senhaHashAtual)) {
                            JOptionPane.showMessageDialog(this, "Senha incorreta. Alteração cancelada.");
                            return;
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Usuário não encontrado.");
                        return;
                    }

                    // Hash da nova senha antes de atualizar
                    String novaSenhaHash = BCrypt.hashpw(senhaNova, BCrypt.gensalt());

                    // Atualiza nome e senha
                    String sqlUpdate = "UPDATE usuarios SET nome = ?, senha = ? WHERE id = ?";
                    PreparedStatement stmtUpdate = conexao.prepareStatement(sqlUpdate);
                    stmtUpdate.setString(1, nomeNovo);
                    stmtUpdate.setString(2, novaSenhaHash);
                    stmtUpdate.setInt(3, id);

                    stmtUpdate.executeUpdate();

                    JOptionPane.showMessageDialog(this, "Usuário alterado com sucesso!");

                    stmtBusca.close();
                    stmtUpdate.close();

                    // Atualizar a tabela depois de alterar
                    jBotaoAtualizarActionPerformed(null);

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "Erro ao alterar: " + e.getMessage());
                }

            } else {
                JOptionPane.showMessageDialog(this, "ID inválido. Atualize a tabela e selecione uma linha válida.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma linha da tabela para alterar.");
        }
    }//GEN-LAST:event_jBotaoAlterarActionPerformed

    private void jBotaoDeletarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBotaoDeletarActionPerformed
        int linha = jTabelaCadastro.getSelectedRow();

        if (linha >= 0) {
            Object valorId = jTabelaCadastro.getValueAt(linha, 0);

            if (valorId != null) {
                int id = Integer.parseInt(valorId.toString());

                // Pede senha para confirmação da exclusão
                String senhaConfirmacao = JOptionPane.showInputDialog(this, "Digite a senha do usuário para confirmar exclusão:");

                if (senhaConfirmacao == null || senhaConfirmacao.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Exclusão cancelada: senha não informada.");
                    return;
                }

                try (Connection conexao = Conexao.conectar()) {
                    String sqlBusca = "SELECT senha FROM usuarios WHERE id = ?";
                    PreparedStatement stmtBusca = conexao.prepareStatement(sqlBusca);
                    stmtBusca.setInt(1, id);
                    ResultSet rs = stmtBusca.executeQuery();

                    if (rs.next()) {
                        String senhaHash = rs.getString("senha");
                        if (!BCrypt.checkpw(senhaConfirmacao, senhaHash)) {
                            JOptionPane.showMessageDialog(this, "Senha incorreta. Exclusão cancelada.");
                            return;
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Usuário não encontrado.");
                        return;
                    }

                    String sqlDelete = "DELETE FROM usuarios WHERE id = ?";
                    PreparedStatement stmtDelete = conexao.prepareStatement(sqlDelete);
                    stmtDelete.setInt(1, id);
                    stmtDelete.executeUpdate();

                    JOptionPane.showMessageDialog(this, "Usuário deletado com sucesso!");

                    stmtBusca.close();
                    stmtDelete.close();

                    // Atualizar tabela depois da exclusão
                    jBotaoAtualizarActionPerformed(null);

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "Erro ao deletar: " + e.getMessage());
                }

            } else {
                JOptionPane.showMessageDialog(this, "O ID selecionado é inválido.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma linha da tabela para deletar.");
        }
    }//GEN-LAST:event_jBotaoDeletarActionPerformed

    private void jBotaoResetarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBotaoResetarActionPerformed
        // Pergunta confirmação ao usuário com caixa de diálogo
        int opcao = JOptionPane.showConfirmDialog(this,
                "Tem certeza que deseja resetar tudo?\nTodos os usuários serão apagados e o ID começará do 1.",
                "Confirmação de Reset",
                JOptionPane.YES_NO_OPTION);

        if (opcao == JOptionPane.YES_OPTION) { // Se usuário confirmou
            try (Connection conexao = Conexao.conectar()) {
                java.sql.Statement stmt = conexao.createStatement();

                // Deleta todos os registros da tabela usuarios
                stmt.executeUpdate("DELETE FROM usuarios");

                // Reseta contador do auto_increment para 1
                stmt.executeUpdate("ALTER TABLE usuarios AUTO_INCREMENT = 1");

                JOptionPane.showMessageDialog(this, "Sistema resetado com sucesso!");

                // Limpa os campos de entrada da interface
                jUsuario.setText("");
                jSenha.setText("");

                // Limpa seleção da tabela
                jTabelaCadastro.clearSelection();

                // Atualiza a tabela para refletir o reset
                jBotaoAtualizarActionPerformed(null);

                stmt.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Erro ao resetar: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_jBotaoResetarActionPerformed

    // Método main: ponto de entrada da aplicação
    public static void main(String args[]) {
        // Configura aparência da aplicação para o Nimbus (se disponível)
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            // Tratar exceções relacionadas ao look and feel (log se necessário)
        }

        // Executa interface gráfica na thread de eventos do Swing
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaNome().setVisible(true); // Abre a janela principal
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBotaoAlterar;
    private javax.swing.JButton jBotaoAtualizar;
    private javax.swing.JButton jBotaoCadastro;
    private javax.swing.JButton jBotaoDeletar;
    private javax.swing.JButton jBotaoEntrar;
    private javax.swing.JButton jBotaoResetar;
    private javax.swing.JButton jBotaoSair;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jSenha;
    private javax.swing.JTable jTabelaCadastro;
    private javax.swing.JTextField jUsuario;
    // End of variables declaration//GEN-END:variables
}
